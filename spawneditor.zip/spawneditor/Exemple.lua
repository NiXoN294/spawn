TEAM_XYESOS = DarkRP.createJob("Администратор", {
	color = Color(0, 150, 10, 255),
	model = {
        ""
		},
	weapons = {"weapon_fists"},
	description = [[]],
	command = "xyesos",
	max = 0,
	salary = 0,
	admin = 0,
	vote = false,
	hasLicense = true,
	SpawnPoint = {									-- Можно приписать к любой профе
		Vector(-340.062286, 3377.076172, 40.031250), -- чтобы узнать координаты нужно написать в консоль на сервере getpos
		Vector(-406.840271, 3631.971680, 40.031250),
		Vector(-449.225342, 3840.736328, 40.031250),
		Vector(-488.885162, 4113.872559, 40.031250)
	}
})